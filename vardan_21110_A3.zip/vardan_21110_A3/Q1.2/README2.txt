In this assignment we have implemented forking to create 3 process which have the save work that is to compile the cpy 
of linux kernel source with minimum config.I have used waitpid so as to get the process ID after execution of that process and then I have
wrote the time to an output text file named as ans.txt. same is done with other two processes.I have uploaded images because somehow i was
unable to push it to my git repository.